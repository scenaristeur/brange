package org.favedave.hello;


import org.janusproject.kernel.Kernel;
import org.janusproject.kernel.agent.Kernels;
 
public class MainProgram {
 
	public static void main(String[] args) {
		//HelloTestAgent t = new HelloTestAgent();
		AgentA a = new AgentA();
		AgentB b = new AgentB();
		
		Kernel k = Kernels.get();
		k.launchLightAgent(b, "Bernard");
		k.launchLightAgent(a, "Aristide");
	}
 
}